const path = require("path");
const express = require("express");
const nodemailer = require("nodemailer");

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const ROOT = __dirname;
const DIST_DIR = path.join(ROOT, "dist");

app.disable("x-powered-by");
app.use(express.json({ limit: "32kb" }));
app.use(express.urlencoded({ extended: false, limit: "32kb" }));

function smtpReady() {
  return Boolean(
    process.env.SMTP_HOST &&
      process.env.SMTP_PORT &&
      process.env.SMTP_USER &&
      process.env.SMTP_PASS &&
      process.env.MAIL_FROM &&
      process.env.MAIL_TO,
  );
}

function cleanText(value, maxLength) {
  return typeof value === "string" ? value.trim().replace(/\r?\n/g, " ").slice(0, maxLength) : "";
}

function cleanMultilineText(value, maxLength) {
  return typeof value === "string" ? value.trim().replace(/\r\n/g, "\n").slice(0, maxLength) : "";
}

function isValidEmail(value) {
  return value === "" || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

app.post("/api/contact", async (req, res) => {
  if (!smtpReady()) {
    return res.status(503).json({ success: false, error: "Formularz jest chwilowo niedostępny." });
  }

  const name = cleanText(req.body?.name, 120);
  const phone = cleanText(req.body?.phone, 60);
  const email = cleanText(req.body?.email, 254);
  const service = cleanText(req.body?.service, 120);
  const message = cleanMultilineText(req.body?.message, 5000);
  const rodo = req.body?.rodo === true || req.body?.rodo === "true";

  if (!name || !phone || !message || !rodo || !isValidEmail(email)) {
    return res.status(400).json({ success: false, error: "Wypełnij poprawnie wymagane pola formularza." });
  }

  const port = Number(process.env.SMTP_PORT);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    return res.status(503).json({ success: false, error: "Formularz jest chwilowo niedostępny." });
  }

  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port,
    secure: process.env.SMTP_SECURE === "true",
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
    connectionTimeout: 10_000,
    greetingTimeout: 10_000,
    socketTimeout: 12_000,
  });

  const subjectName = name.replace(/[\r\n]/g, " ");
  const lines = [
    "Nowe zapytanie ze strony IGOMAX",
    "",
    `Imię i nazwisko: ${name}`,
    `Telefon: ${phone}`,
    `E-mail: ${email || "nie podano"}`,
    `Zakres usługi: ${service || "nie podano"}`,
    "",
    "Wiadomość:",
    message,
    "",
    "Zgoda RODO: tak",
  ];

  try {
    await transporter.sendMail({
      from: process.env.MAIL_FROM,
      to: process.env.MAIL_TO,
      replyTo: email || undefined,
      subject: `Nowe zapytanie od ${subjectName} – IGOMAX`,
      text: lines.join("\n"),
    });
    return res.status(200).json({ success: true });
  } catch (error) {
    console.error("SMTP send failed:", error instanceof Error ? error.message : "unknown error");
    return res.status(502).json({ success: false, error: "Nie udało się wysłać wiadomości. Spróbuj ponownie później." });
  }
});

app.use("/images", express.static(path.join(ROOT, "images"), { maxAge: "7d", fallthrough: false }));
app.use(express.static(DIST_DIR, { maxAge: "1h" }));
app.get("*", (_req, res) => res.sendFile(path.join(DIST_DIR, "index.html")));

app.listen(PORT, "0.0.0.0", () => {
  console.log(`IGOMAX listening on 0.0.0.0:${PORT}`);
});
